export interface Movie {
  id?: string | number;
  title: string;
  overview: string;      
  poster_path: string;   
  release_date: string;  
  vote_average: number;  
  genre_ids?: number[];  
}

